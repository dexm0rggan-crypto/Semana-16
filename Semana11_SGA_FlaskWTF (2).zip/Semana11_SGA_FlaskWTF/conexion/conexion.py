import psycopg2

def obtener_conexion():
    try:
        conn = psycopg2.connect(
            host="localhost",
            database="postgres",
            user="postgres",
            password="1234",
            port="5432"
        )
        return conn
    except Exception as e:
        print("Error al conectar a PostgreSQL:", repr(e))
        return None