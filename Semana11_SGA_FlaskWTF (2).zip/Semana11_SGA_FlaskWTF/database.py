import psycopg2

def obtener_conexion():
    try:
        conn = psycopg2.connect(
            host="localhost",
            database="postgres",
            user="postgres",
            password="1234",
            port="5432"
        )
        return conn
    except Exception as e:
        error_limpio = str(e).encode('ascii', 'ignore').decode('ascii')
        print(f"Error al conectar a la base de datos PostgreSQL: {error_limpio}")
        return None